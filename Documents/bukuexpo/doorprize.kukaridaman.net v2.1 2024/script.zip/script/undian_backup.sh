#!/bin/sh

mysqldump -u root -pKuk4r1daman undian > /var/backups/db/undian/undian-quiz-$(date +%d-%m-%Y_%H-%M-%S).sql
